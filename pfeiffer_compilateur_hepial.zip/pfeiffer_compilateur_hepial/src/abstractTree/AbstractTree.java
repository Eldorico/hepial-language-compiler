package abstractTree;

public abstract class AbstractTree {

	@Override
	abstract public String toString();

}
