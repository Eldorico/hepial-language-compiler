package codeProduction;

public interface JEvaluable {
    public void accept(JEvaluator visitor);
}
